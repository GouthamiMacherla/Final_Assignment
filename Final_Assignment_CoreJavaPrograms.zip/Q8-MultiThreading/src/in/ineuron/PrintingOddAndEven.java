package in.ineuron;

class EvenThread extends Thread
{
	public void run()
	{
		for(int i = 2; i<= 10 ; i+= 2)
		{
			System.out.println(i);
		}
	}
}
class OddThread extends Thread
{
	public void run()
	{
		for(int i=1 ; i <= 9 ;i += 2)
		{
			System.out.println(i);
		}
	}
}
public class PrintingOddAndEven {

	public static void main(String[] args) {
		
		EvenThread even = new EvenThread();
		OddThread odd = new OddThread();
		even.start();
		odd.start();
	}

}
