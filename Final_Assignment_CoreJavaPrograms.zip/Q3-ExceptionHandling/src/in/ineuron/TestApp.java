package in.ineuron;
import java.util.Scanner;

public class TestApp {

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		
		try {
			//entering a user positive integer
			System.out.print("Enter a Positive Integer :");
		    int number = scanner.nextInt();
		    
		    //check if the number is negative
		    if(number < 0)
		    {
		    	//throw an exception
		    	throw new IllegalArgumentException("Number cannot be negative");
		    }
		    
		    //print the number
		    System.out.println("Number : " +number);
		}
		catch(Exception e)
		{
			//handling the exception
			System.out.println("Error :" +e.getMessage());
			
		}finally {
			//close the scanner
			scanner.close();
		}
    }

}
