import java.util.*;

//define the shape interface
interface Shape{
	double getArea();
	double getPerimeter();
}
//define a circle class that implements the shapes interface
class Circle implements Shape{
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	public double getArea() {
		return Math.PI * radius *radius;
	}
	
	public double getPerimeter() {
		return 2 * Math.PI * radius;
	}
}

//defining a Triangle class that implements the shape interface
class Triangle implements Shape{
	private double base;
	private double height;
	private double side1;
	private double side2;
	private double side3;
	
	public Triangle(double base,double height, double side1,double side2,double side3) {
		this.base = base;
		this.height = height;
		this.side1  = side1;
		this.side2 = side2;
		this.side3 = side3;
	}
	
	public double getArea() {
		return 0.5 * base * height;
	}
	
	public double getPerimeter() {
		return side1 + side2 + side3;
	}
}
public class Shapes {

	public static void main(String[] args) {
		
		double circleRadius = 5.0;
		//creating a circle object
		Shape circle = new Circle(circleRadius);
		
		//creating a Triangle object
		Shape triangle = new Triangle(4.0,3.0,5.0,4.0,3.0);
		
		//printing the area and perimeter of the circle
		System.out.println("Circle area : " +circle.getArea());
		System.out.println("Circle perimeter : " +circle.getPerimeter());
		
		//printing the area and perimeter of the Triangle
		System.out.println("Triangle area :" +triangle.getArea());
		System.out.println("Triangle perimeter :" +triangle.getPerimeter());
		// TODO Auto-generated method stub

	}

}
