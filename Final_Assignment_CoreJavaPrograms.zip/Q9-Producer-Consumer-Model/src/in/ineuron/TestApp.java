package in.ineuron;

import java.util.Queue;
import java.util.Random;
import java.util.LinkedList;

class Producer implements Runnable
{
	private Queue<Integer> queue;
	private int maxSize;
	
	public Producer(Queue<Integer> queue , int maxSize)
	{
		this.queue = queue;
		this.maxSize = maxSize;
	}
	
	public void run()
	{
		while(true)
		{
			synchronized(queue) {
				while(queue.size() == maxSize)
				{
					try {
						queue.wait();
					}catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				Random random = new Random();
				int number = random.nextInt(10);
				System.out.println("Producer number : "  + number);
				queue.add(number);
				queue.notify();
				
			}
		}
	}
}
class Consumer implements Runnable
{
	private Queue<Integer> queue;
	
	public Consumer(Queue<Integer> queue)
	{
		this.queue = queue;
	}
	
	public void run()
	{
		while(true) {
			synchronized(queue) {
				while(queue.isEmpty())
				{
					try {
						queue.wait();
					}catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				int sum = 0;
				while(!queue.isEmpty())
				{
					int number = queue.poll();
					sum+= number;
				}
				System.out.println("Consumed sum : "  +sum);
				queue.notify();
			}
		}
	}
}
public class TestApp {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new LinkedList<>();
		int maxSize = 10;
		Producer p = new Producer(queue , maxSize);
		Consumer c = new Consumer(queue);
		Thread producerThread = new Thread(p);
		Thread consumerThread = new Thread(c);
		producerThread.start();
		consumerThread.start();

	}

}

