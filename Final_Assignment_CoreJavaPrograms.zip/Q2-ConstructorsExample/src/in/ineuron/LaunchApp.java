package in.ineuron;

class Parent{
	private int parentValue;
	
	public Parent(int value) {
		this.parentValue = value;
		System.out.println("Parent Constructor Called with value : " +this.parentValue);
	}
}

class Child extends Parent
{
	private int childValue;
	
	public Child(int parentValue,int childValue)
	{
		super(parentValue); //invoking the parent class constructor
		this.childValue = childValue;
		System.out.println("Child constructor called with value : " +this.childValue);
	}
}

 public class LaunchApp {

	public static void main(String[] args) {
		//creating a child object
		Child ch = new Child(10 , 20);
	}

}
