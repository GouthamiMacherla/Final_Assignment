package in.ineuron.diff;


abstract class Animal{
	protected String name;
	
	public Animal(String name)
	{
		this.name = name;
	}
	
	public abstract void makeSound();
	
	public void eat()
	{
		System.out.println(name    +   "is eating");
	}
}
class Dog extends Animal
{
	public Dog(String name)
	{
		super(name);
	}
	
	public void makeSound()
	{
		System.out.println(name    +   "is barking");
	}
}
public class ExampleAbstract {

	public static void main(String[] args) {
		
		Dog d = new Dog("Rex");
		d.makeSound();
		d.eat();
	}

}
