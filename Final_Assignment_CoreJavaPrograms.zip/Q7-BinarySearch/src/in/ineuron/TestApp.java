package in.ineuron;

import java.util.Scanner;

public class TestApp 
{
	public static int search(int[] array , int target)
	{
	int left = 0;
	int right = array.length - 1;
	
	
	while(left <= right)
	{
		int mid = left +(right - left) / 2;
		
		if(array[mid] == target)
		{
			return mid;
		}
		
		if(array[mid] < target) {
			left = mid+1;
			
		}else {
			right = mid-1;
		}
	}
	return -1;
}

	public static void main(String[] args) {
		
		//sorted array for testing
		int[] array = {1,3,5,7,9,11,13,15,17,19};
		
		//Get target value from the user
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the target value : ");
		int target = scanner.nextInt();
		
		//Perform binary search
		int index = search(array ,target);
		
		//Display the result
		if(index!= -1) {
			System.out.println("Target value found at index : " +index);

	}else {
		System.out.println("Target value not found in the array");
	}
		scanner.close();

  }
}
