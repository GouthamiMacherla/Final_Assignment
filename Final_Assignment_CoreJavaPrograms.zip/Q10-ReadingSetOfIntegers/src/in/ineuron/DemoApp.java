package in.ineuron;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class DemoApp {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		List<Integer> numbers = new ArrayList<>();
		System.out.print("Enter the number of elements :");
		int n = scanner.nextInt();
		System.out.print("Enter" +n+ "integers : ");
		for(int i =0 ;i<n ;i++)
		{
			int number = scanner.nextInt();
			numbers.add(number);
		}
		Collections.sort(numbers);
		int secondLargest = numbers.get(numbers.size() - 2);
		int secondSmallest = numbers.get(1);
		System.out.println("The Second Largest element is :"  +secondLargest);
		System.out.println("The Second Smallest element is :" +secondSmallest);
		
		scanner.close();

	}

}
