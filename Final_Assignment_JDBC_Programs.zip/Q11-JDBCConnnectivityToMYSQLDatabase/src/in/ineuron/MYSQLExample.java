package in.ineuron;

import java.sql.Connection;
import java.sql.Statement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MYSQLExample {

	public static void main(String[] args) throws SQLException {
		
		//step 2.Establish the connection
		String url = "jdbc:mysql:///pwskills";
		String user = "root";
		String password = "MacherlaGouthami_3!";
		Connection connection = DriverManager.getConnection(url,user,password);
		System.out.println("CONNECTION  object created...");
		
		
		//step 3..Create statement object and send the query
		
		Statement statement = connection.createStatement();
		System.out.println("STATEMENT object created...");
		
		//step 4..Execute the query and process the resultset
		String sqlSelectQuery = "select sid,sname,sage,saddress from student";
		ResultSet resultset = statement.executeQuery(sqlSelectQuery);
		System.out.println("RESULTSET object created..");
		System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
		while(resultset.next())
		{
			int sid = resultset.getInt("sid");
			String sname = resultset.getString("sname");
			int sage = resultset.getInt("sage");
			String saddress = resultset.getString("saddress");
			System.out.println(sid + "\t" + sname + "\t" + sage + "\t" +saddress);
		}
		
		//step 6..Close the resources
		resultset.close();
		statement.close();
		connection.close();
		System.out.println("Closing the resources...");
	}

}
