package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test")
public class DataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	Connection connection = null;
	
	static {
		try {
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			System.out.println("Driver loaded successfully...");
			
			
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void init() throws ServletException{
		System.out.println("config object created and got the values from config  object ...\n");
		
		String url = getInitParameter("url");
		String username = getInitParameter("username");
		String password = getInitParameter("password");
		System.out.println(url);
		System.out.println(username);
		System.out.println(password);
		
		try {
			connection = DriverManager.getConnection(url, username, password);
			if(connection != null) {
				System.out.println("Connection established successfully...");
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String URL ="jdbc:mysql:///pwskils";
	static final String user = "root";
	static final String password ="MacherlaGouthami_3!";
	@Override
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
     PrintWriter out = response.getWriter().append("Served at: ").append(request.getContextPath());
     out.println("<h1> Request type is :: " + request.getMethod() + "</h1>");
     
     Statement statement = null;
     ResultSet resultset = null;
     try {
    	 statement = connection.createStatement();
    	 resultset = statement.executeQuery("select id,name,age,saddress from student");
    	 
    	 
    	 //generate html response
    	 out.println("<html>");
    	 out.println("<head><title> Table Data</title></head>");
    	 out.println("<body>");
    	 out.println("<table>");
    	 out.println("<tr><th>id</th><th>name</th></tr>");
    	 out.println("<tr><th>age</th><th>saddress</th></tr>");
    	 
    	 
    	 //iterate over the result set and generate table rows
    	 while(resultset.next())
    	 {
 
    		 int sid = resultset.getInt("sid");
 			 String sname = resultset.getString("sname");
 			 int sage = resultset.getInt("sage");
 			 String saddress = resultset.getString("saddress");
 			 System.out.println(sid + "\t" + sname + "\t" + sage + "\t" + saddress);
 		}
    	 out.println("</table>");
    	 out.println("</body>");
    	 out.println("</html>");
   }catch(SQLException se) {
	   se.printStackTrace();
   }catch(Exception e) {
	   e.printStackTrace();
   }finally {
	   //close resources
	   try {
		   if(resultset != null)
			   resultset.close();
	   }catch(SQLException se1) {
		   
	   }
	   try {
		   if(statement != null)
			   statement.close();
	   }catch(SQLException se2) {
		   
	   }
	   try {
		   if(connection != null)
			   connection.close();
	   }catch(SQLException se3) {
		   se3.printStackTrace();
	   }
   }
}

}
