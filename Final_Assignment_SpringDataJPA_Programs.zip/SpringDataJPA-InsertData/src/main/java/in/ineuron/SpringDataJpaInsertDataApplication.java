package in.ineuron;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.bo.CoronaVaccine1;
import in.ineuron.service.ICoronaVaccineMgmtService;

@SpringBootApplication
public class SpringDataJpaInsertDataApplication {




	private static CoronaVaccine1 vaccine;

	public static  void main(String[] args) {
		ConfigurableApplicationContext factory = SpringApplication.run(SpringDataJpaInsertDataApplication.class, args);
	
	    ICoronaVaccineMgmtService service = factory.getBean(ICoronaVaccineMgmtService.class);
	    new CoronaVaccine1(null , "covaxin" ,"Bharath-biotech" , "IND" ,234.0 , null);
	    
	    
		System.out.println(service.registerVaccine(vaccine));
	    ((ConfigurableApplicationContext) factory).close();
	
	
	}

}
