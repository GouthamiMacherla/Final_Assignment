package in.ineuron.dao;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.bo.CoronaVaccine1;

public interface ICoronaVaccineRepo extends CrudRepository<CoronaVaccine1, Long> {

	 public String registerVaccine(CoronaVaccine1 vaccine);

}
