package in.ineuron.service;

import in.ineuron.bo.CoronaVaccine1;

public interface ICoronaVaccineMgmtService {
	
	public String registerVaccine(CoronaVaccine1 vaccine);

}
