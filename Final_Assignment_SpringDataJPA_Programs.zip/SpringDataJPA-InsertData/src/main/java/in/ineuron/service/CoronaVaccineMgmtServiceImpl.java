package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.bo.CoronaVaccine1;
import in.ineuron.dao.ICoronaVaccineRepo;


@Service("service")
public abstract class CoronaVaccineMgmtServiceImpl  implements ICoronaVaccineRepo 
{
	
	@Autowired
	private ICoronaVaccineRepo repo;
	
	@Override
	public String registerVaccine(CoronaVaccine1 vaccine) {
		System.out.println("In Memory proxy class is  :: " +repo.getClass().getName());
		
		CoronaVaccine1 saveVaccine = null;
		if(vaccine != null) {
			saveVaccine = repo.save(vaccine);
		}
		
		return saveVaccine != null ?"vaccine registered successfully with" +saveVaccine.getRegNo()
				 :"vaccine registration failed";
	}

}
