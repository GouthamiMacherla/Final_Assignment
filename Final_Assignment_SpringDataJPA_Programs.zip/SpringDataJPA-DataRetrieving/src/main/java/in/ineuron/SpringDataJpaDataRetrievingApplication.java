package in.ineuron;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.dao.DataAccessException;

import in.ineuron.bo.CoronaVaccine;
import in.ineuron.service.ICoronaVaccineMgmtService;

@SpringBootApplication
public class SpringDataJpaDataRetrievingApplication {

	public static  void main(String[] args) {
		ConfigurableApplicationContext factory = SpringApplication.run(SpringDataJpaDataRetrievingApplication.class, args);
		ICoronaVaccineMgmtService service = factory.getBean(ICoronaVaccineMgmtService.class);
		
		 CoronaVaccine vaccine = new
				CoronaVaccine("covidshield","serum","IND",450.0,2);
				
				  CoronaVaccine vaccine1 = new CoronaVaccine();
				  vaccine1.setPrice(450.0);
				  service.searchVaccinesByGivenData(vaccine1, false ,"price","name").forEach(System.out::println);
				  ((ConfigurableApplicationContext) factory).close();
				 
				
				// try {
				//	 CoronaVaccine vaccine11 = service.getVaccineById(10L);
				//	 if (vaccine11 != null) { 
				//       System.out.println("vaccine details are :: " + vaccine11);
				 //    }else {
				//       System.out.println("Record not available for the given id");
				//     }
				 //}catch(DataAccessException e) 
				// { 
					// System.out.println(e.getMessage());
				// }
				
	}

}
