package in.ineuron.session;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SessionObject")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

     public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
    	 
    	 //read the user's name from the form
    	String name = request.getParameter("name");
    	
    	//create a session object
    	HttpSession session = request.getSession();
    	
    	//store the user's name in the session
    	session.setAttribute("name",name);
    	
    	//redirect to the welcome page
    	response.sendRedirect("Welcome.jsp");

	}

}
